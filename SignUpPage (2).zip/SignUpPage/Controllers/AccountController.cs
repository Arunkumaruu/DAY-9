﻿using Microsoft.AspNetCore.Mvc;
using SignUpPage.Models;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SignUpPage.Controllers
{
    public class AccountController : Controller
    {
        private readonly string connectionString = "Data Source=KUMAR\\SQLEXPRESS;Initial Catalog=signupp;Integrated Security=True;Trusted_Connection=True;TrustServerCertificate=True;";

        // State and City Lists
        private readonly Dictionary<string, List<SelectListItem>> _statesAndCities = new()
{
    { "Andhra Pradesh", new List<SelectListItem>
        {
            new("Anantapur", "Anantapur"),
            new("Chittoor", "Chittoor"),
            new("East Godavari", "East Godavari"),
            new("Guntur", "Guntur"),
            new("Krishna", "Krishna"),
            new("Kurnool", "Kurnool"),
            new("Nellore", "Nellore"),
            new("Prakasam", "Prakasam"),
            new("Srikakulam", "Srikakulam"),
            new("Visakhapatnam", "Visakhapatnam"),
            new("Vizianagaram", "Vizianagaram"),
            new("West Godavari", "West Godavari"),
            new("YSR Kadapa", "YSR Kadapa")
        }
    },
    { "Arunachal Pradesh", new List<SelectListItem>
        {
            new("Anjaw", "Anjaw"),
            new("Changlang", "Changlang"),
            new("Dibang Valley", "Dibang Valley"),
            new("East Kameng", "East Kameng"),
            new("East Siang", "East Siang"),
            new("Kamle", "Kamle"),
            new("Kra Daadi", "Kra Daadi"),
            new("Kurung Kumey", "Kurung Kumey"),
            new("Lepa Rada", "Lepa Rada"),
            new("Lohit", "Lohit"),
            new("Longding", "Longding"),
            new("Lower Dibang Valley", "Lower Dibang Valley"),
            new("Lower Siang", "Lower Siang"),
            new("Lower Subansiri", "Lower Subansiri"),
            new("Namsai", "Namsai"),
            new("Pakke Kessang", "Pakke Kessang"),
            new("Papum Pare", "Papum Pare"),
            new("Shi Yomi", "Shi Yomi"),
            new("Siang", "Siang"),
            new("Tawang", "Tawang"),
            new("Tirap", "Tirap"),
            new("Upper Siang", "Upper Siang"),
            new("Upper Subansiri", "Upper Subansiri"),
            new("West Kameng", "West Kameng"),
            new("West Siang", "West Siang")
        }
    },
    { "Assam", new List<SelectListItem>
        {
            new("Baksa", "Baksa"),
            new("Barpeta", "Barpeta"),
            new("Biswanath", "Biswanath"),
            new("Bongaigaon", "Bongaigaon"),
            new("Cachar", "Cachar"),
            new("Charaideo", "Charaideo"),
            new("Chirang", "Chirang"),
            new("Darrang", "Darrang"),
            new("Dhemaji", "Dhemaji"),
            new("Dhubri", "Dhubri"),
            new("Dibrugarh", "Dibrugarh"),
            new("Dima Hasao", "Dima Hasao"),
            new("Goalpara", "Goalpara"),
            new("Golaghat", "Golaghat"),
            new("Hailakandi", "Hailakandi"),
            new("Hojai", "Hojai"),
            new("Jorhat", "Jorhat"),
            new("Kamrup", "Kamrup"),
            new("Kamrup Metropolitan", "Kamrup Metropolitan"),
            new("Karbi Anglong", "Karbi Anglong"),
            new("Karimganj", "Karimganj"),
            new("Kokrajhar", "Kokrajhar"),
            new("Lakhimpur", "Lakhimpur"),
            new("Majuli", "Majuli"),
            new("Morigaon", "Morigaon"),
            new("Nagaon", "Nagaon"),
            new("Nalbari", "Nalbari"),
            new("Sivasagar", "Sivasagar"),
            new("Sonitpur", "Sonitpur"),
            new("South Salmara-Mankachar", "South Salmara-Mankachar"),
            new("Tinsukia", "Tinsukia"),
            new("Udalguri", "Udalguri"),
            new("West Karbi Anglong", "West Karbi Anglong")
        }
    },
    { "Bihar", new List<SelectListItem>
        {
            new("Araria", "Araria"),
            new("Arwal", "Arwal"),
            new("Aurangabad", "Aurangabad"),
            new("Banka", "Banka"),
            new("Begusarai", "Begusarai"),
            new("Bhagalpur", "Bhagalpur"),
            new("Bhojpur", "Bhojpur"),
            new("Buxar", "Buxar"),
            new("Darbhanga", "Darbhanga"),
            new("East Champaran", "East Champaran"),
            new("Gaya", "Gaya"),
            new("Gopalganj", "Gopalganj"),
            new("Jamui", "Jamui"),
            new("Jehanabad", "Jehanabad"),
            new("Kaimur", "Kaimur"),
            new("Katihar", "Katihar"),
            new("Khagaria", "Khagaria"),
            new("Kishanganj", "Kishanganj"),
            new("Lakhisarai", "Lakhisarai"),
            new("Madhepura", "Madhepura"),
            new("Madhubani", "Madhubani"),
            new("Munger", "Munger"),
            new("Muzaffarpur", "Muzaffarpur"),
            new("Nalanda", "Nalanda"),
            new("Nawada", "Nawada"),
            new("Patna", "Patna"),
            new("Purnia", "Purnia"),
            new("Rohtas", "Rohtas"),
            new("Saharsa", "Saharsa"),
            new("Samastipur", "Samastipur"),
            new("Saran", "Saran"),
            new("Sheikhpura", "Sheikhpura"),
            new("Sheohar", "Sheohar"),
            new("Sitamarhi", "Sitamarhi"),
            new("Siwan", "Siwan"),
            new("Supaul", "Supaul"),
            new("Vaishali", "Vaishali"),
            new("West Champaran", "West Champaran")
        }
    },
    { "Chhattisgarh", new List<SelectListItem>
        {
            new("Balod", "Balod"),
            new("Baloda Bazar", "Baloda Bazar"),
            new("Balrampur", "Balrampur"),
            new("Bastar", "Bastar"),
            new("Bemetara", "Bemetara"),
            new("Bijapur", "Bijapur"),
            new("Bilaspur", "Bilaspur"),
            new("Dantewada", "Dantewada"),
            new("Dhamtari", "Dhamtari"),
            new("Durg", "Durg"),
            new("Gariaband", "Gariaband"),
            new("Gaurela Pendra Marwahi", "Gaurela Pendra Marwahi"),
            new("Janjgir Champa", "Janjgir Champa"),
            new("Jashpur", "Jashpur"),
            new("Kabirdham", "Kabirdham"),
            new("Kanker", "Kanker"),
            new("Kondagaon", "Kondagaon"),
            new("Korba", "Korba"),
            new("Koriya", "Koriya"),
            new("Mahasamund", "Mahasamund"),
            new("Mungeli", "Mungeli"),
            new("Narayanpur", "Narayanpur"),
            new("Raigarh", "Raigarh"),
            new("Raipur", "Raipur"),
            new("Rajnandgaon", "Rajnandgaon"),
            new("Sukma", "Sukma"),
            new("Surajpur", "Surajpur"),
            new("Surguja", "Surguja")
        }
    },
    { "Goa", new List<SelectListItem>
        {
            new("North Goa", "North Goa"),
            new("South Goa", "South Goa")
        }
    },
    { "Gujarat", new List<SelectListItem>
        {
            new("Ahmedabad", "Ahmedabad"),
            new("Amreli", "Amreli"),
            new("Anand", "Anand"),
            new("Aravalli", "Aravalli"),
            new("Banaskantha", "Banaskantha"),
            new("Bharuch", "Bharuch"),
            new("Bhavnagar", "Bhavnagar"),
            new("Botad", "Botad"),
            new("Chhota Udaipur", "Chhota Udaipur"),
            new("Dahod", "Dahod"),
            new("Dang", "Dang"),
            new("Devbhoomi Dwarka", "Devbhoomi Dwarka"),
            new("Gandhinagar", "Gandhinagar"),
            new("Gir Somnath", "Gir Somnath"),
            new("Jamnagar", "Jamnagar"),
            new("Junagadh", "Junagadh"),
            new("Kachchh", "Kachchh"),
            new("Mehsana", "Mehsana"),
            new("Narmada", "Narmada"),
            new("Navsari", "Navsari"),
            new("Panchmahal", "Panchmahal"),
            new("Patan", "Patan"),
            new("Porbandar", "Porbandar"),
            new("Rajkot", "Rajkot"),
            new("Sabarkantha", "Sabarkantha"),
            new("Surat", "Surat"),
            new("Surendranagar", "Surendranagar"),
            new("Tapi", "Tapi"),
            new("Vadodara", "Vadodara"),
            new("Valsad", "Valsad")
        }
    },
    { "Haryana", new List<SelectListItem>
        {
            new("Ambala", "Ambala"),
            new("Bhiwani", "Bhiwani"),
            new("Faridabad", "Faridabad"),
            new("Fatehabad", "Fatehabad"),
            new("Gurugram", "Gurugram"),
            new("Hisar", "Hisar"),
            new("Jind", "Jind"),
            new("Kaithal", "Kaithal"),
            new("Karnal", "Karnal"),
            new("Mahendragarh", "Mahendragarh"),
            new("Mewat", "Mewat"),
            new("Panchkula", "Panchkula"),
            new("Panipat", "Panipat"),
            new("Rewari", "Rewari"),
            new("Sirsa", "Sirsa"),
            new("Sonipat", "Sonipat"),
            new("Yamunanagar", "Yamunanagar")
        }
    },
    { "Himachal Pradesh", new List<SelectListItem>
        {
            new("Bilaspur", "Bilaspur"),
            new("Chamba", "Chamba"),
            new("Hamirpur", "Hamirpur"),
            new("Kangra", "Kangra"),
            new("Kinnaur", "Kinnaur"),
            new("Kullu", "Kullu"),
            new("Lahaul and Spiti", "Lahaul and Spiti"),
            new("Mandi", "Mandi"),
            new("Shimla", "Shimla"),
            new("Sirmaur", "Sirmaur"),
            new("Solan", "Solan"),
            new("Una", "Una")
        }
    },
    { "Jharkhand", new List<SelectListItem>
        {
            new("Bokaro", "Bokaro"),
            new("Chatra", "Chatra"),
            new("Deoghar", "Deoghar"),
            new("Dhanbad", "Dhanbad"),
            new("Dumka", "Dumka"),
            new("East Singhbhum", "East Singhbhum"),
            new("Garhwa", "Garhwa"),
            new("Giridih", "Giridih"),
            new("Godda", "Godda"),
            new("Gumla", "Gumla"),
            new("Hazaribag", "Hazaribag"),
            new("Jamtara", "Jamtara"),
            new("Khunti", "Khunti"),
            new("Koderma", "Koderma"),
            new("Latehar", "Latehar"),
            new("Lohardaga", "Lohardaga"),
            new("Pakur", "Pakur"),
            new("Palamu", "Palamu"),
            new("Ranchi", "Ranchi"),
            new("Sahibganj", "Sahibganj"),
            new("Seraikela Kharsawan", "Seraikela Kharsawan"),
            new("Simdega", "Simdega"),
            new("West Singhbhum", "West Singhbhum")
        }
    },
    { "Karnataka", new List<SelectListItem>
        {
            new("Bagalkot", "Bagalkot"),
            new("Ballari", "Ballari"),
            new("Belagavi", "Belagavi"),
            new("Bengaluru Rural", "Bengaluru Rural"),
            new("Bengaluru Urban", "Bengaluru Urban"),
            new("Bidar", "Bidar"),
            new("Chamarajanagar", "Chamarajanagar"),
            new("Chikkaballapura", "Chikkaballapura"),
            new("Chikkamagalur", "Chikkamagalur"),
            new("Chitradurga", "Chitradurga"),
            new("Dakshina Kannada", "Dakshina Kannada"),
            new("Davanagere", "Davanagere"),
            new("Dharwad", "Dharwad"),
            new("Gadag", "Gadag"),
            new("Hassan", "Hassan"),
            new("Haveri", "Haveri"),
            new("Kalaburagi", "Kalaburagi"),
            new("Kodagu", "Kodagu"),
            new("Kolar", "Kolar"),
            new("Koppal", "Koppal"),
            new("Mandya", "Mandya"),
            new("Mysuru", "Mysuru"),
            new("Raichur", "Raichur"),
            new("Ramanagara", "Ramanagara"),
            new("Shimoga", "Shimoga"),
            new("Tumakuru", "Tumakuru"),
            new("Udupi", "Udupi"),
            new("Uttara Kannada", "Uttara Kannada"),
            new("Yadgir", "Yadgir")
        }
    },
    { "Kerala", new List<SelectListItem>
        {
            new("Alappuzha", "Alappuzha"),
            new("Ernakulam", "Ernakulam"),
            new("Idukki", "Idukki"),
            new("Kannur", "Kannur"),
            new("Kasaragod", "Kasaragod"),
            new("Kollam", "Kollam"),
            new("Kottayam", "Kottayam"),
            new("Kozhikode", "Kozhikode"),
            new("Malappuram", "Malappuram"),
            new("Palakkad", "Palakkad"),
            new("Pathanamthitta", "Pathanamthitta"),
            new("Thrissur", "Thrissur"),
            new("Wayanad", "Wayanad")
        }
    },
    { "Ladakh", new List<SelectListItem>
        {
            new("Leh", "Leh"),
            new("Kargil", "Kargil")
        }
    },
    { "Lakshadweep", new List<SelectListItem>
        {
            new("Lakshadweep", "Lakshadweep")
        }
    },
    { "Madhya Pradesh", new List<SelectListItem>
        {
            new("Agar Malwa", "Agar Malwa"),
            new("Alirajpur", "Alirajpur"),
            new("Ashok Nagar", "Ashok Nagar"),
            new("Balaghat", "Balaghat"),
            new("Barwani", "Barwani"),
            new("Betul", "Betul"),
            new("Bhind", "Bhind"),
            new("Bhopal", "Bhopal"),
            new("Burhanpur", "Burhanpur"),
            new("Chhindwara", "Chhindwara"),
            new("Damoh", "Damoh"),
            new("Datia", "Datia"),
            new("Dewas", "Dewas"),
            new("Dhar", "Dhar"),
            new("Dindori", "Dindori"),
            new("Guna", "Guna"),
            new("Gwalior", "Gwalior"),
            new("Harda", "Harda"),
            new("Hoshangabad", "Hoshangabad"),
            new("Indore", "Indore"),
            new("Jabalpur", "Jabalpur"),
            new("Jhabua", "Jhabua"),
            new("Katni", "Katni"),
            new("Khandwa", "Khandwa"),
            new("Khargone", "Khargone"),
            new("Mandla", "Mandla"),
            new("Mandsaur", "Mandsaur"),
            new("Morena", "Morena"),
            new("Narmadapuram", "Narmadapuram"),
            new("Narsinghpur", "Narsinghpur"),
            new("Neemuch", "Neemuch"),
            new("Pachmarhi", "Pachmarhi"),
            new("Panna", "Panna"),
            new("Rajgarh", "Rajgarh"),
            new("Raisen", "Raisen"),
            new("Rajauli", "Rajauli"),
            new("Ratlam", "Ratlam"),
            new("Rewa", "Rewa"),
            new("Sagar", "Sagar"),
            new("Satna", "Satna"),
            new("Sehore", "Sehore"),
            new("Seoni", "Seoni"),
            new("Shahdol", "Shahdol"),
            new("Shajapur", "Shajapur"),
            new("Shivpuri", "Shivpuri"),
            new("Sidhi", "Sidhi"),
            new("Singrauli", "Singrauli"),
            new("Tikamgarh", "Tikamgarh"),
            new("Ujjain", "Ujjain"),
            new("Umaria", "Umaria"),
            new("Vidisha", "Vidisha")
        }
    },
    { "Maharashtra", new List<SelectListItem>
        {
            new("Ahmednagar", "Ahmednagar"),
            new("Akola", "Akola"),
            new("Amravati", "Amravati"),
            new("Aurangabad", "Aurangabad"),
            new("Beed", "Beed"),
            new("Bhandara", "Bhandara"),
            new("Buldhana", "Buldhana"),
            new("Chandrapur", "Chandrapur"),
            new("Dhule", "Dhule"),
            new("Gadchiroli", "Gadchiroli"),
            new("Gondia", "Gondia"),
            new("Hingoli", "Hingoli"),
            new("Jalgaon", "Jalgaon"),
            new("Jalna", "Jalna"),
            new("Kolhapur", "Kolhapur"),
            new("Latur", "Latur"),
            new("Mumbai City", "Mumbai City"),
            new("Mumbai Suburban", "Mumbai Suburban"),
            new("Nagpur", "Nagpur"),
            new("Nanded", "Nanded"),
            new("Nandurbar", "Nandurbar"),
            new("Nashik", "Nashik"),
            new("Osmanabad", "Osmanabad"),
            new("Palghar", "Palghar"),
            new("Parbhani", "Parbhani"),
            new("Pune", "Pune"),
            new("Raigad", "Raigad"),
            new("Ratnagiri", "Ratnagiri"),
            new("Sindhudurg", "Sindhudurg"),
            new("Solapur", "Solapur"),
            new("Thane", "Thane"),
            new("Wardha", "Wardha"),
            new("Washim", "Washim"),
            new("Yavatmal", "Yavatmal")
        }
    },
    { "Manipur", new List<SelectListItem>
        {
            new("Bishnupur", "Bishnupur"),
            new("Chandel", "Chandel"),
            new("Churachandpur", "Churachandpur"),
            new("Imphal East", "Imphal East"),
            new("Imphal West", "Imphal West"),
            new("Jiribam", "Jiribam"),
            new("Kakching", "Kakching"),
            new("Kamjong", "Kamjong"),
            new("Noney", "Noney"),
            new("Pherzawl", "Pherzawl"),
            new("Senapati", "Senapati"),
            new("Tamenglong", "Tamenglong"),
            new("Thoubal", "Thoubal"),
            new("Ukhrul", "Ukhrul")
        }
    },
    { "Meghalaya", new List<SelectListItem>
        {
            new("East Garo Hills", "East Garo Hills"),
            new("East Khasi Hills", "East Khasi Hills"),
            new("Jaintia Hills", "Jaintia Hills"),
            new("North Garo Hills", "North Garo Hills"),
            new("Ri Bhoi", "Ri Bhoi"),
            new("South Garo Hills", "South Garo Hills"),
            new("West Garo Hills", "West Garo Hills"),
            new("West Khasi Hills", "West Khasi Hills")
        }
    },
    { "Mizoram", new List<SelectListItem>
        {
            new("Aizawl", "Aizawl"),
            new("Champhai", "Champhai"),
            new("Kolasib", "Kolasib"),
            new("Lawngtlai", "Lawngtlai"),
            new("Lunglei", "Lunglei"),
            new("Mamit", "Mamit"),
            new("Saiha", "Saiha"),
            new("Serchhip", "Serchhip")
        }
    },
    { "Nagaland", new List<SelectListItem>
        {
            new("Dimapur", "Dimapur"),
            new("Kiphire", "Kiphire"),
            new("Kohima", "Kohima"),
            new("Longleng", "Longleng"),
            new("Mokokchung", "Mokokchung"),
            new("Mon", "Mon"),
            new("Peren", "Peren"),
            new("Phek", "Phek"),
            new("Tuensang", "Tuensang"),
            new("Wokha", "Wokha"),
            new("Zunheboto", "Zunheboto")
        }
    },
    { "Odisha", new List<SelectListItem>
        {
            new("Angul", "Angul"),
            new("Balangir", "Balangir"),
            new("Balasore", "Balasore"),
            new("Bargarh", "Bargarh"),
            new("Bhadrak", "Bhadrak"),
            new("Boudh", "Boudh"),
            new("Cuttack", "Cuttack"),
            new("Dhenkanal", "Dhenkanal"),
            new("Gajapati", "Gajapati"),
            new("Ganjam", "Ganjam"),
            new("Jagatsinghpur", "Jagatsinghpur"),
            new("Jajpur", "Jajpur"),
            new("Jeypore", "Jeypore"),
            new("Kalahandi", "Kalahandi"),
            new("Kandhamal", "Kandhamal"),
            new("Kendrapara", "Kendrapara"),
            new("Kendujhar", "Kendujhar"),
            new("Khurda", "Khurda"),
            new("Koraput", "Koraput"),
            new("Malkangiri", "Malkangiri"),
            new("Nabarangpur", "Nabarangpur"),
            new("Nayagarh", "Nayagarh"),
            new("Nuapada", "Nuapada"),
            new("Rayagada", "Rayagada"),
            new("Sambalpur", "Sambalpur"),
            new("Subarnapur", "Subarnapur"),
            new("Sundargarh", "Sundargarh")
        }
    },
    { "Puducherry", new List<SelectListItem>
        {
            new("Karaikal", "Karaikal"),
            new("Mahe", "Mahe"),
            new("Puducherry", "Puducherry"),
            new("Yanam", "Yanam")
        }
    },
    { "Punjab", new List<SelectListItem>
        {
            new("Amritsar", "Amritsar"),
            new("Barnala", "Barnala"),
            new("Bathinda", "Bathinda"),
            new("Faridkot", "Faridkot"),
            new("Fatehgarh Sahib", "Fatehgarh Sahib"),
            new("Firozpur", "Firozpur"),
            new("Gurdaspur", "Gurdaspur"),
            new("Hoshiarpur", "Hoshiarpur"),
            new("Jalandhar", "Jalandhar"),
            new("Kapurthala", "Kapurthala"),
            new("Ludhiana", "Ludhiana"),
            new("Mansa", "Mansa"),
            new("Moga", "Moga"),
            new("Muktsar", "Muktsar"),
            new("Nawanshahr", "Nawanshahr"),
            new("Pathankot", "Pathankot"),
            new("Patiala", "Patiala"),
            new("Rupnagar", "Rupnagar"),
            new("Sangrur", "Sangrur"),
            new("SAS Nagar", "SAS Nagar"),
            new("Sri Muktsar Sahib", "Sri Muktsar Sahib"),
            new("Tarn Taran", "Tarn Taran")
        }
    },
    { "Rajasthan", new List<SelectListItem>
        {
            new("Ajmer", "Ajmer"),
            new("Alwar", "Alwar"),
            new("Banswara", "Banswara"),
            new("Baran", "Baran"),
            new("Barmer", "Barmer"),
            new("Bharatpur", "Bharatpur"),
            new("Bhilwara", "Bhilwara"),
            new("Bikaner", "Bikaner"),
            new("Bundi", "Bundi"),
            new("Chittorgarh", "Chittorgarh"),
            new("Churu", "Churu"),
            new("Dausa", "Dausa"),
            new("Dungarpur", "Dungarpur"),
            new("Hanumangarh", "Hanumangarh"),
            new("Jaipur", "Jaipur"),
            new("Jaisalmer", "Jaisalmer"),
            new("Jalore", "Jalore"),
            new("Jhalawar", "Jhalawar"),
            new("Jhunjhunu", "Jhunjhunu"),
            new("Jodhpur", "Jodhpur"),
            new("Karauli", "Karauli"),
            new("Nagaur", "Nagaur"),
            new("Pali", "Pali"),
            new("Rajasthan", "Rajasthan"),
            new("Sawai Madhopur", "Sawai Madhopur"),
            new("Sikar", "Sikar"),
            new("Sirohi", "Sirohi"),
            new("Tonk", "Tonk"),
            new("Udaipur", "Udaipur")
        }
    },
    { "Sikkim", new List<SelectListItem>
        {
            new("East Sikkim", "East Sikkim"),
            new("North Sikkim", "North Sikkim"),
            new("South Sikkim", "South Sikkim"),
            new("West Sikkim", "West Sikkim")
        }
    },
    { "home Nadu", new List<SelectListItem>
        {
            new("Ariyalur", "Ariyalur"),
            new("Chengalpattu", "Chengalpattu"),
            new("Chennai", "Chennai"),
            new("Coimbatore", "Coimbatore"),
            new("Cuddalore", "Cuddalore"),
            new("Dharmapuri", "Dharmapuri"),
            new("Dindigul", "Dindigul"),
            new("Kallakurichi", "Kallakurichi"),
            new("Kancheepuram", "Kancheepuram"),
            new("Kanyakumari", "Kanyakumari"),
            new("Karur", "Karur"),
            new("Madurai", "Madurai"),
            new("Nagapattinam", "Nagapattinam"),
            new("Namakkal", "Namakkal"),
            new("Nilgiris", "Nilgiris"),
            new("Perambalur", "Perambalur"),
            new("Pudukkottai", "Pudukkottai"),
            new("Ramanathapuram", "Ramanathapuram"),
            new("Salem", "Salem"),
            new("Sivaganga", "Sivaganga"),
            new("Tenkasi", "Tenkasi"),
            new("Thanjavur", "Thanjavur"),
            new("The Nilgiris", "The Nilgiris"),
            new("Theni", "Theni"),
            new("Thiruvallur", "Thiruvallur"),
            new("Thiruvannamalai", "Thiruvannamalai"),
            new("Tiruchirappalli", "Tiruchirappalli"),
            new("Tirunelveli", "Tirunelveli"),
            new("Tiruppur", "Tiruppur"),
            new("Vellore", "Vellore"),
            new("Villupuram", "Villupuram"),
            new("Virudhunagar", "Virudhunagar")
        }
    },
    { "Telangana", new List<SelectListItem>
        {
            new("Adilabad", "Adilabad"),
            new("Bhadradri Kothagudem", "Bhadradri Kothagudem"),
            new("Hyderabad", "Hyderabad"),
            new("Jagtial", "Jagtial"),
            new("Jangaon", "Jangaon"),
            new("Jangoan", "Jangoan"),
            new("Jayashankar Bhupalpally", "Jayashankar Bhupalpally"),
            new("Jogulamba Gadwal", "Jogulamba Gadwal"),
            new("Kamareddy", "Kamareddy"),
            new("Karimnagar", "Karimnagar"),
            new("Khammam", "Khammam"),
            new("Mahabubnagar", "Mahabubnagar"),
            new("Mancherial", "Mancherial"),
            new("Medak", "Medak"),
            new("Medchal Malkajgiri", "Medchal Malkajgiri"),
            new("Nagarkurnool", "Nagarkurnool"),
            new("Nalgonda", "Nalgonda"),
            new("Nirmal", "Nirmal"),
            new("Nizamabad", "Nizamabad"),
            new("Peddapalli", "Peddapalli"),
            new("Rajanna Sircilla", "Rajanna Sircilla"),
            new("Rangareddy", "Rangareddy"),
            new("Warangal", "Warangal"),
            new("Yadadri Bhuvanagiri", "Yadadri Bhuvanagiri")
        }
    },
    { "Tripura", new List<SelectListItem>
        {
            new("Dhalai", "Dhalai"),
            new("Khowai", "Khowai"),
            new("North Tripura", "North Tripura"),
            new("Sepahijala", "Sepahijala"),
            new("South Tripura", "South Tripura"),
            new("Unakoti", "Unakoti"),
            new("West Tripura", "West Tripura")
        }
    },
    { "Uttar Pradesh", new List<SelectListItem>
        {
            new("Agra", "Agra"),
            new("Aligarh", "Aligarh"),
            new("Allahabad", "Allahabad"),
            new("Ambedkar Nagar", "Ambedkar Nagar"),
            new("Amethi", "Amethi"),
            new("Auraiya", "Auraiya"),
            new("Azamgarh", "Azamgarh"),
            new("Baghpat", "Baghpat"),
            new("Bahraich", "Bahraich"),
            new("Ballia", "Ballia"),
            new("Banda", "Banda"),
            new("Barabanki", "Barabanki"),
            new("Bareilly", "Bareilly"),
            new("Basti", "Basti"),
            new("Bijnor", "Bijnor"),
            new("Budaun", "Budaun"),
            new("Bulandshahr", "Bulandshahr"),
            new("Chandauli", "Chandauli"),
            new("Chitrakoot", "Chitrakoot"),
            new("Deoria", "Deoria"),
            new("Etah", "Etah"),
            new("Etawah", "Etawah"),
            new("Faizabad", "Faizabad"),
            new("Farrukhabad", "Farrukhabad"),
            new("Fatehpur", "Fatehpur"),
            new("Firozabad", "Firozabad"),
            new("Gautam Buddha Nagar", "Gautam Buddha Nagar"),
            new("Ghaziabad", "Ghaziabad"),
            new("Ghazipur", "Ghazipur"),
            new("Gonda", "Gonda"),
            new("Gorakhpur", "Gorakhpur"),
            new("Hamirpur", "Hamirpur"),
            new("Hapur", "Hapur"),
            new("Hardoi", "Hardoi"),
            new("Hathras", "Hathras"),
            new("Jalaun", "Jalaun"),
            new("Jaunpur", "Jaunpur"),
            new("Jhansi", "Jhansi"),
            new("Kannauj", "Kannauj"),
            new("Kanpur Dehat", "Kanpur Dehat"),
            new("Kanpur Nagar", "Kanpur Nagar"),
            new("Kushinagar", "Kushinagar"),
            new("Lakhimpur Kheri", "Lakhimpur Kheri"),
            new("Lalitpur", "Lalitpur"),
            new("Lucknow", "Lucknow"),
            new("Maharajganj", "Maharajganj"),
            new("Mahoba", "Mahoba"),
            new("Mainpuri", "Mainpuri"),
            new("Mathura", "Mathura"),
            new("Meerut", "Meerut"),
            new("Mirzapur", "Mirzapur"),
            new("Moradabad", "Moradabad"),
            new("Muzaffarnagar", "Muzaffarnagar"),
            new("Pilibhit", "Pilibhit"),
            new("Pratapgarh", "Pratapgarh"),
            new("Rae Bareli", "Rae Bareli"),
            new("Rampur", "Rampur"),
            new("Saharanpur", "Saharanpur"),
            new("Sant Kabir Nagar", "Sant Kabir Nagar"),
            new("Shahjahanpur", "Shahjahanpur"),
            new("Shamli", "Shamli"),
            new("Shravasti", "Shravasti"),
            new("Siddharthnagar", "Siddharthnagar"),
            new("Sitapur", "Sitapur"),
            new("Sonbhadra", "Sonbhadra"),
            new("Sultanpur", "Sultanpur"),
            new("Unnao", "Unnao"),
            new("Varanasi", "Varanasi")
        }
    },
    { "Uttarakhand", new List<SelectListItem>
        {
            new("Almora", "Almora"),
            new("Bageshwar", "Bageshwar"),
            new("Champawat", "Champawat"),
            new("Dehradun", "Dehradun"),
            new("Haridwar", "Haridwar"),
            new("Nainital", "Nainital"),
            new("Pauri Garhwal", "Pauri Garhwal"),
            new("Pithoragarh", "Pithoragarh"),
            new("Rudraprayag", "Rudraprayag"),
            new("Tehri Garhwal", "Tehri Garhwal"),
            new("Udham Singh Nagar", "Udham Singh Nagar"),
            new("Uttarkashi", "Uttarkashi")
        }
    },
    { "West Bengal", new List<SelectListItem>
        {
            new("Alipurduar", "Alipurduar"),
            new("Bankura", "Bankura"),
            new("Birbhum", "Birbhum"),
            new("Burdwan", "Burdwan"),
            new("Cooch Behar", "Cooch Behar"),
            new("Darjeeling", "Darjeeling"),
            new("Hooghly", "Hooghly"),
            new("Howrah", "Howrah"),
            new("Jalpaiguri", "Jalpaiguri"),
            new("Jhargram", "Jhargram"),
            new("Kolkata", "Kolkata"),
            new("Maldah", "Maldah"),
            new("Murshidabad", "Murshidabad"),
            new("Nadia", "Nadia"),
            new("North 24 Parganas", "North 24 Parganas"),
            new("Purba Bardhaman", "Purba Bardhaman"),
            new("Purulia", "Purulia"),
            new("South 24 Parganas", "South 24 Parganas"),
            new("Uttar Dinajpur", "Uttar Dinajpur"),
            new("West Bardhaman", "West Bardhaman"),
            new("West Dinajpur", "West Dinajpur")
        }
    }
};

        [HttpGet]
        public IActionResult SignUp()
        {
            var states = new List<SelectListItem>
            {
                new SelectListItem { Value = "Select State", Text = "Select State" }
            };

            foreach (var state in _statesAndCities.Keys)
            {
                states.Add(new SelectListItem { Value = state, Text = state });
            }

            ViewBag.States = states;
            ViewBag.Cities = new List<SelectListItem>(); // Empty list initially

            return View();
        }

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using var conn = new SqlConnection(connectionString);
                    using var cmd = new SqlCommand("sp_RegisterUser", conn)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@Username", user.Username);
                    cmd.Parameters.AddWithValue("@Password", user.Password);
                    cmd.Parameters.AddWithValue("@Email", user.Email);
                    cmd.Parameters.AddWithValue("@FirstName", user.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", user.LastName);
                    cmd.Parameters.AddWithValue("@DateOfBirth", user.DateOfBirth);
                    cmd.Parameters.AddWithValue("@Gender", user.Gender);
                    cmd.Parameters.AddWithValue("@PhoneNumber", user.PhoneNumber);
                    cmd.Parameters.AddWithValue("@Address", user.Address);
                    cmd.Parameters.AddWithValue("@State", user.State);
                    cmd.Parameters.AddWithValue("@City", user.City);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    return RedirectToAction("SignUpSuccess");
                }
                catch (SqlException)
                {
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request.");
                }
                catch (Exception)
                {
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request.");
                }
            }

            // Re-set the ViewBag properties if the ModelState is not valid
            var states = new List<SelectListItem>
            {
                new SelectListItem { Value = "Select State", Text = "Select State" }
            };

            foreach (var state in _statesAndCities.Keys)
            {
                states.Add(new SelectListItem { Value = state, Text = state });
            }

            ViewBag.States = states;
            ViewBag.Cities = new List<SelectListItem>(); // Empty list initially

            return View(user);
        }

        [HttpGet]
        public JsonResult GetCities(string state)
        {
            var cities = new List<SelectListItem>();

            if (_statesAndCities.TryGetValue(state, out var cityList))
            {
                cities = cityList;
            }

            return Json(cities);
        }

        public IActionResult SignUpSuccess()
        {
            return View();
        }
    }
}
